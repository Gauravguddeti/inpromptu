(function(){var Z=Object.defineProperty;var tt=(s,t,e)=>t in s?Z(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var c=(s,t,e)=>tt(s,typeof t!="symbol"?t+"":t,e);function et(s){let t=5381;for(let e=0;e<s.length;e++)t=t*33^s.charCodeAt(e);return(t>>>0).toString(36)}function nt(s,t){if(!s)return{changedSpan:{start:0,end:t.length}};const e=rt(t),n=s.split(/\n\n+/);let r=-1;for(let d=0;d<e.length;d++){const u=n[d]??"";if(e[d].text!==u){r=d;break}}if(r===-1){const d=e[e.length-1];return{changedSpan:{start:(d==null?void 0:d.start)??0,end:t.length}}}const i=Math.max(0,r-1),o=Math.min(e.length-1,r+1),a=e[i].start,l=e[o].end;return{changedSpan:{start:a,end:l}}}function rt(s){const t=[],e=/\n\n+/g;let n=0,r;for(;(r=e.exec(s))!==null;)t.push({text:s.slice(n,r.index),start:n,end:r.index}),n=r.index+r[0].length;return t.push({text:s.slice(n),start:n,end:s.length}),t}const st="https://inpromptu-backend.onrender.com/log";function L(s){fetch(st,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(s),keepalive:!0}).catch(()=>{console.warn("[PromptCoach Logger] Backend log endpoint unreachable")})}function O(s,t,e,n){return{level:s,message:t,context:e,stack:n==null?void 0:n.stack,url:window.location.href,timestamp:new Date().toISOString()}}const h={error(s,t,e){console.error(`[PromptCoach] ${s}`,e??""),L(O("error",s,t,e))},warn(s,t){console.warn(`[PromptCoach] ${s}`),L(O("warn",s,t))},info(s,t){console.log(`[PromptCoach] ${s}`),L(O("info",s,t))},debug(s,t){console.debug(`[PromptCoach] ${s}`)}};function it(){window.addEventListener("error",s=>{h.error(`Uncaught: ${s.message}`,`${s.filename}:${s.lineno}`,s.error instanceof Error?s.error:void 0)}),window.addEventListener("unhandledrejection",s=>{const t=s.reason instanceof Error?s.reason.message:String(s.reason);h.error(`Unhandled promise rejection: ${t}`,"promise",s.reason instanceof Error?s.reason:void 0)})}const ot="pc_session_ctx_",_="pc_session_id";function at(){let s=sessionStorage.getItem(_);return s||(s=`sess_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,sessionStorage.setItem(_,s)),s}function M(){return`${ot}${location.hostname}`}function k(){try{const s=localStorage.getItem(M());return s?JSON.parse(s):null}catch{return null}}function j(s){try{localStorage.setItem(M(),JSON.stringify(s))}catch{}}function lt(){localStorage.removeItem(M())}function W(s,t){const e={summary:s,promptCount:0,lastUpdatedAt:Date.now(),sourceUrl:location.href,scannedMessageCount:t};return j(e),e}function ct(s,t){const e=k(),n={summary:s,promptCount:t,lastUpdatedAt:Date.now(),sourceUrl:location.href,scannedMessageCount:(e==null?void 0:e.scannedMessageCount)??0};return j(n),n}const dt=900,ut=/[.?!\n]/;let R=null,B="",U="";function ht(s,t){s.onTextChange(e=>{pt(e,s,t)}),h.info(`Debounce engine initialized for adapter: ${s.name}`,"debounce")}function pt(s,t,e){if(!s.trim()){e.clear();return}const n=s[s.length-1],r=ut.test(n);R&&clearTimeout(R),r?D(s,t,e):R=setTimeout(()=>{D(s,t,e)},dt)}async function D(s,t,e){const n=et(s.trim());if(n===U){h.debug("Skipping — same hash as last analysis","debounce");return}const r=nt(B,s),i=k(),o={text:s,changedSpan:r.changedSpan,promptHash:n,sessionContext:i==null?void 0:i.summary};B=s,U=n,e.setAnalysisPending(!0),e.setLoading(!0),h.debug(`Sending analysis request (${s.length} chars${i?", with context":""})`,"debounce");try{const a=await gt(o);a&&e.render(a,t)}catch(a){h.error("Analysis request failed","debounce",a instanceof Error?a:new Error(String(a))),e.setAnalysisPending(!1)}finally{e.setLoading(!1)}}function gt(s){return new Promise((t,e)=>{const n={type:"ANALYZE_REQUEST",payload:s,requestId:crypto.randomUUID()};chrome.runtime.sendMessage(n,r=>{var i;if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if((r==null?void 0:r.type)==="ERROR"){e(new Error(((i=r.payload)==null?void 0:i.message)??"Service worker error"));return}t((r==null?void 0:r.payload)??null)})})}const ft=["#prompt-textarea",'div[contenteditable="true"][class*="ProseMirror"]','div[contenteditable="true"][data-virtualkeyboard-content]','div.ProseMirror[contenteditable="true"]','[data-testid="composer-speech-button"] ~ div[contenteditable="true"]','div[contenteditable="true"]'];class mt{constructor(){c(this,"name","ChatGPT");c(this,"editor",null);c(this,"mutationObserver",null);c(this,"textChangeCallbacks",[]);c(this,"submitCallbacks",[]);c(this,"submitListener",null)}getEditorElement(){if(this.editor&&document.contains(this.editor))return this.editor;for(const t of ft){const e=document.querySelector(t);if(e)return this.editor=e,this.attachObserver(),e}return null}getText(){const t=this.getEditorElement();return t?t.innerText??t.textContent??"":""}getOffsetMap(){const t=this.getEditorElement();return t?S(t):[]}replaceRange(t,e,n){const r=this.getEditorElement();if(!r)return;const i=S(r),o=N(i,t,e);if(!o)return;o.deleteContents(),o.insertNode(document.createTextNode(n));const a=window.getSelection();if(a){a.removeAllRanges();const l=document.createRange();l.setStart(o.startContainer,o.startOffset+n.length),l.collapse(!0),a.addRange(l)}r.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0}))}setText(t){const e=this.getEditorElement();if(!e)return;e.textContent=t;const n=window.getSelection();if(n){const r=document.createRange();r.selectNodeContents(e),r.collapse(!1),n.removeAllRanges(),n.addRange(r)}e.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0}))}onTextChange(t){this.textChangeCallbacks.push(t),this.mutationObserver||this.getEditorElement()}getConversationHistory(t=10){const e=[],n=document.querySelectorAll('article[data-testid^="conversation-turn"], [data-message-author-role]');return!n.length&&!document.querySelector('main [class*="react-scroll"]')?[]:(n.forEach(r=>{var l;const i=r.getAttribute("data-message-author-role")??((l=r.getAttribute("data-testid"))!=null&&l.includes("user")?"user":"assistant"),o=r.querySelector('[class*="markdown"], [data-message-content], .whitespace-pre-wrap, p'),a=((o==null?void 0:o.textContent)??r.textContent??"").trim();a&&(i==="user"||i==="assistant")&&e.push({role:i,content:a.slice(0,500)})}),e.slice(-t))}onSubmit(t){this.submitCallbacks.push(t),!this.submitListener&&(this.submitListener=e=>{const n=e;if(n.key!=="Enter"||n.shiftKey)return;const r=this.getText().trim();r&&setTimeout(()=>this.submitCallbacks.forEach(i=>i(r)),50)},document.addEventListener("keydown",this.submitListener,{capture:!0}),document.addEventListener("click",e=>{if(!e.target.closest('[data-testid="send-button"], button[aria-label*="Send"]'))return;const i=this.getText().trim();i&&setTimeout(()=>this.submitCallbacks.forEach(o=>o(i)),50)},{capture:!0}))}destroy(){var t;(t=this.mutationObserver)==null||t.disconnect(),this.mutationObserver=null,this.textChangeCallbacks=[],this.submitCallbacks=[],this.submitListener&&(document.removeEventListener("keydown",this.submitListener,{capture:!0}),this.submitListener=null)}attachObserver(){if(this.mutationObserver||!this.editor)return;let t="";this.mutationObserver=new MutationObserver(()=>{const e=this.getText();e!==t&&(t=e,this.textChangeCallbacks.forEach(n=>n(e)))}),this.mutationObserver.observe(this.editor,{characterData:!0,childList:!0,subtree:!0})}}function S(s){var i;const t=[],e=document.createTreeWalker(s,NodeFilter.SHOW_TEXT,null);let n=0,r;for(;r=e.nextNode();){const o=((i=r.textContent)==null?void 0:i.length)??0;t.push({node:r,nodeStart:n,nodeEnd:n+o}),n+=o;const a=r.parentElement;a&&bt(a)&&a.lastChild===r&&(n+=1)}return t}function bt(s){const t=window.getComputedStyle(s).display;return t==="block"||t==="flex"||t==="grid"}function N(s,t,e){let n=null,r=0,i=null,o=0;for(const l of s)if(!n&&l.nodeEnd>t&&(n=l.node,r=t-l.nodeStart),!i&&l.nodeEnd>=e){i=l.node,o=e-l.nodeStart;break}if(!n||!i)return null;const a=document.createRange();return a.setStart(n,Math.min(r,n.length)),a.setEnd(i,Math.min(o,i.length)),a}const yt=['div.ProseMirror[contenteditable="true"]','[data-testid="chat-input"] [contenteditable="true"]','.composer [contenteditable="true"]','fieldset [contenteditable="true"]','div[contenteditable="true"][class*="ProseMirror"]','div[contenteditable="true"]'];class xt{constructor(){c(this,"name","Claude");c(this,"editor",null);c(this,"mutationObserver",null);c(this,"textChangeCallbacks",[]);c(this,"submitCallbacks",[]);c(this,"submitListener",null)}getEditorElement(){if(this.editor&&document.contains(this.editor))return this.editor;for(const t of yt){const e=document.querySelectorAll(t);for(const n of e){const r=n.getBoundingClientRect();if(r.width>0||r.height>0||n.textContent)return this.editor=n,this.attachObserver(),n}}return null}getText(){const t=this.getEditorElement();return t?t.innerText??t.textContent??"":""}getOffsetMap(){const t=this.getEditorElement();return t?S(t):[]}replaceRange(t,e,n){const r=this.getEditorElement();if(!r)return;const i=S(r),o=N(i,t,e);if(!o)return;o.deleteContents(),o.insertNode(document.createTextNode(n));const a=window.getSelection();if(a){a.removeAllRanges();const l=document.createRange();l.setStart(o.startContainer,o.startOffset+n.length),l.collapse(!0),a.addRange(l)}r.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0})),r.dispatchEvent(new InputEvent("keydown",{bubbles:!0,cancelable:!0}))}setText(t){const e=this.getEditorElement();if(!e)return;e.textContent=t;const n=window.getSelection();if(n){const r=document.createRange();r.selectNodeContents(e),r.collapse(!1),n.removeAllRanges(),n.addRange(r)}e.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0}))}onTextChange(t){this.textChangeCallbacks.push(t),this.mutationObserver||this.getEditorElement()}getConversationHistory(t=10){const e=[];return document.querySelectorAll('[data-message-author-role], .human-turn, .claude-message, [class*="ConversationItem"]').forEach(r=>{let i="user";const o=r.getAttribute("data-message-author-role");if(o==="assistant"||r.classList.contains("claude-message"))i="assistant";else if(o==="human"||r.classList.contains("human-turn"))i="user";else return;const a=(r.textContent??"").trim().slice(0,500);a&&e.push({role:i,content:a})}),e.slice(-t)}onSubmit(t){this.submitCallbacks.push(t),!this.submitListener&&(this.submitListener=e=>{const n=e;if(n.key!=="Enter"||n.shiftKey)return;const r=this.getText().trim();r&&setTimeout(()=>this.submitCallbacks.forEach(i=>i(r)),50)},document.addEventListener("keydown",this.submitListener,{capture:!0}),document.addEventListener("click",e=>{if(!e.target.closest('[aria-label*="Send"], [data-testid*="send"]'))return;const r=this.getText().trim();r&&setTimeout(()=>this.submitCallbacks.forEach(i=>i(r)),50)},{capture:!0}))}destroy(){var t;(t=this.mutationObserver)==null||t.disconnect(),this.mutationObserver=null,this.textChangeCallbacks=[],this.submitCallbacks=[],this.submitListener&&(document.removeEventListener("keydown",this.submitListener,{capture:!0}),this.submitListener=null)}attachObserver(){if(this.mutationObserver||!this.editor)return;let t="";this.mutationObserver=new MutationObserver(()=>{const e=this.getText();e!==t&&(t=e,this.textChangeCallbacks.forEach(n=>n(e)))}),this.mutationObserver.observe(this.editor,{characterData:!0,childList:!0,subtree:!0})}}class Et{constructor(){c(this,"name","Generic");c(this,"editor",null);c(this,"mirror",null);c(this,"mutationObserver",null);c(this,"inputHandler",null);c(this,"textChangeCallbacks",[])}getEditorElement(){if(this.editor&&document.contains(this.editor))return this.editor;const t=document.activeElement;if(t&&vt(t))return this.editor=t,this.attachObserver(),t;const e=document.querySelector('[contenteditable="true"]');if(e)return this.editor=e,this.attachObserver(),e;const n=document.querySelector("textarea");return n?(this.editor=n,this.attachObserver(),n):null}getText(){const t=this.getEditorElement();return t?A(t)?t.value:t.innerText??t.textContent??"":""}getOffsetMap(){const t=this.getEditorElement();return t?A(t)?this.buildTextareaOffsetMap(t):S(t):[]}replaceRange(t,e,n){const r=this.getEditorElement();if(!r)return;if(A(r)){const a=r,l=a.value;a.value=l.slice(0,t)+n+l.slice(e),a.selectionStart=a.selectionEnd=t+n.length,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0}));return}const i=S(r),o=N(i,t,e);o&&(o.deleteContents(),o.insertNode(document.createTextNode(n)),r.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0})))}setText(t){const e=this.getEditorElement();if(e)if(A(e)){const n=e;n.value=t,n.selectionStart=n.selectionEnd=t.length,n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}))}else e.textContent=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0}))}onTextChange(t){this.textChangeCallbacks.push(t),!this.mutationObserver&&!this.inputHandler&&this.getEditorElement()}getConversationHistory(t){return[]}onSubmit(t){}destroy(){var t,e;(t=this.mutationObserver)==null||t.disconnect(),this.mutationObserver=null,this.inputHandler=null,this.textChangeCallbacks=[],(e=this.mirror)==null||e.remove(),this.mirror=null}buildTextareaOffsetMap(t){const e=this.ensureMirror(t);if(!e)return[];const n=t.value;e.textContent=n;const r=e.firstChild;return r?[{node:r,nodeStart:0,nodeEnd:n.length}]:[]}ensureMirror(t){if(this.mirror&&document.contains(this.mirror)){const l=t.getBoundingClientRect();return this.mirror.style.left=`${l.left+window.scrollX}px`,this.mirror.style.top=`${l.top+window.scrollY}px`,this.mirror.style.width=`${l.width}px`,this.mirror.style.height=`${l.height}px`,this.mirror}const e=document.createElement("div");e.id="pc-textarea-mirror";const n=window.getComputedStyle(t),i=["font-family","font-size","font-weight","font-style","letter-spacing","line-height","text-transform","padding-top","padding-right","padding-bottom","padding-left","border-top-width","border-right-width","border-bottom-width","border-left-width","box-sizing","word-wrap","overflow-wrap","white-space"].map(l=>`${l}:${n.getPropertyValue(l)}`).join(";"),o=t.getBoundingClientRect();e.style.cssText=`
      ${i};
      position: absolute;
      left: ${o.left+window.scrollX}px;
      top: ${o.top+window.scrollY}px;
      width: ${o.width}px;
      height: ${o.height}px;
      overflow: hidden;
      visibility: hidden;
      pointer-events: none;
      white-space: pre-wrap;
      word-wrap: break-word;
      z-index: -9999;
    `,document.body.appendChild(e),this.mirror=e;const a=()=>{if(!this.mirror||!this.editor)return;const l=this.editor.getBoundingClientRect();this.mirror.style.left=`${l.left+window.scrollX}px`,this.mirror.style.top=`${l.top+window.scrollY}px`,this.mirror.style.width=`${l.width}px`,this.mirror.style.height=`${l.height}px`};return window.addEventListener("scroll",a,{passive:!0}),window.addEventListener("resize",a,{passive:!0}),e}attachObserver(){if(this.mutationObserver||this.inputHandler||!this.editor)return;let t="";if(A(this.editor)){const e=()=>{var r;const n=((r=this.editor)==null?void 0:r.value)??"";n!==t&&(t=n,this.textChangeCallbacks.forEach(i=>i(n)))};this.inputHandler=e,this.editor.addEventListener("input",e),this.editor.addEventListener("paste",()=>setTimeout(e,0));return}this.mutationObserver=new MutationObserver(()=>{const e=this.getText();e!==t&&(t=e,this.textChangeCallbacks.forEach(n=>n(e)))}),this.mutationObserver.observe(this.editor,{characterData:!0,childList:!0,subtree:!0})}}function vt(s){return s.tagName==="TEXTAREA"||s.tagName==="INPUT"||s.getAttribute("contenteditable")==="true"}function A(s){return s.tagName==="TEXTAREA"||s.tagName==="INPUT"}const wt=[{match:s=>/chatgpt\.com|chat\.openai\.com/.test(s),Adapter:mt},{match:s=>/claude\.ai/.test(s),Adapter:xt}];let w=null;function St(){const s=window.location.href;w&&(w.destroy(),w=null);for(const{match:e,Adapter:n}of wt)if(e(s)){const r=new n;return r.getEditorElement(),w=r,r}const t=new Et;return w=t,t}function Ct(s){return{red:"#ef4444",yellow:"#f97316",blue:"#3b82f6"}[s]??"#f97316"}function Tt(s){return{red:"rgba(239,68,68,0.1)",yellow:"rgba(249,115,22,0.1)",blue:"rgba(59,130,246,0.1)"}[s]??"rgba(249,115,22,0.1)"}function At(s){return{red:"🔴 Critical",yellow:"🟠 Fixable",blue:"💙 Suggestion"}[s]??"🟠 Fixable"}function kt(s){return["red","yellow","blue"].includes(s)?s:"yellow"}const It=`
  .pc-underline {
    position: fixed;
    pointer-events: all;
    cursor: pointer;
    z-index: 2147483640;
    border-radius: 1px;
    transition: opacity 0.12s;
  }
  .pc-underline:hover { opacity: 0.7; }

  /* Dims underlines while a new analysis is in-flight */
  .pc-underline.pc-pending,
  .pc-additive-badge.pc-pending {
    opacity: 0.3 !important;
    transition: opacity 0.2s;
  }

  /* Wavy underline via border-bottom */
  .pc-underline-red {
    border-bottom: 2.5px solid #ef4444;
    background: rgba(239,68,68,0.04);
  }
  .pc-underline-yellow {
    border-bottom: 2.5px solid #f97316;
    background: rgba(249,115,22,0.04);
  }
  .pc-underline-blue {
    border-bottom: 2px dashed #3b82f6;
    background: rgba(59,130,246,0.04);
  }

  /* '+' badge for additive issues — positioned after last char */
  .pc-additive-badge {
    position: fixed;
    pointer-events: all;
    z-index: 2147483640;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-family: system-ui, sans-serif;
    user-select: none;
    transition: background 0.15s, transform 0.15s, opacity 0.12s;
    animation: pc-badge-pulse 2s ease-in-out infinite;
  }
  @keyframes pc-badge-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(96,165,250,0.4); }
    50%       { box-shadow: 0 0 0 4px rgba(96,165,250,0); }
  }

  /* ── Tooltip ── */
  #pc-tooltip {
    position: fixed;
    z-index: 2147483647;
    background: #1a1a24;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
    width: 300px;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 13px;
    pointer-events: all;
    opacity: 0;
    transform: translateY(4px) scale(0.97);
    transition: opacity 0.18s ease, transform 0.18s ease;
    overflow: hidden;
  }
  #pc-tooltip.pc-visible {
    opacity: 1;
    transform: translateY(0) scale(1);
  }

  .pc-tooltip-header {
    padding: 10px 14px 8px;
    border-bottom: 1px solid rgba(255,255,255,0.06);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .pc-severity-badge {
    font-size: 11px;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 20px;
    letter-spacing: 0.03em;
  }

  .pc-close-btn {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: none;
    background: rgba(255,255,255,0.06);
    color: rgba(255,255,255,0.4);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    line-height: 1;
    transition: all 0.15s;
  }
  .pc-close-btn:hover { background: rgba(255,255,255,0.12); color: white; }

  .pc-tooltip-explanation {
    padding: 10px 14px;
    color: rgba(255,255,255,0.7);
    font-size: 12px;
    line-height: 1.5;
    border-bottom: 1px solid rgba(255,255,255,0.06);
  }

  .pc-suggestions-label {
    padding: 8px 14px 4px;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.3);
  }

  .pc-suggestions { padding: 4px 8px 8px; display: flex; flex-direction: column; gap: 4px; }

  .pc-suggestion-btn {
    width: 100%;
    text-align: left;
    padding: 8px 10px;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 8px;
    color: rgba(255,255,255,0.85);
    font-size: 12px;
    font-family: inherit;
    cursor: pointer;
    transition: all 0.15s;
    line-height: 1.4;
    display: flex;
    align-items: flex-start;
    gap: 8px;
  }
  .pc-suggestion-btn::before { content: '→'; color: rgba(255,255,255,0.3); flex-shrink: 0; font-size: 11px; margin-top: 1px; }
  .pc-suggestion-btn:hover {
    background: rgba(99,102,241,0.15);
    border-color: rgba(99,102,241,0.35);
    color: white;
  }
  .pc-suggestion-btn:hover::before { color: #818cf8; }

  .pc-tooltip-footer {
    padding: 8px 14px;
    border-top: 1px solid rgba(255,255,255,0.06);
    display: flex;
    gap: 6px;
    justify-content: flex-end;
  }

  .pc-ignore-btn {
    padding: 5px 10px;
    border-radius: 6px;
    border: 1px solid rgba(255,255,255,0.08);
    background: transparent;
    color: rgba(255,255,255,0.35);
    font-size: 11px;
    font-family: inherit;
    cursor: pointer;
    transition: all 0.15s;
  }
  .pc-ignore-btn:hover { background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.6); }

  /* ── Loading dot ── */
  #pc-loader {
    position: fixed;
    bottom: 18px;
    right: 18px;
    display: flex;
    align-items: center;
    gap: 6px;
    background: rgba(22,22,30,0.9);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 5px 10px;
    font-family: 'Inter', sans-serif;
    font-size: 11px;
    color: rgba(255,255,255,0.5);
    z-index: 2147483647;
    display: none;
    backdrop-filter: blur(8px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.3);
  }
  #pc-loader.pc-loading { display: flex; }
  .pc-loader-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #6366f1;
    animation: pcPulse 1s ease-in-out infinite;
  }
  @keyframes pcPulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.4; transform: scale(0.75); }
  }
`,E=class E{constructor(){c(this,"underlines",[]);c(this,"tooltip",null);c(this,"loader",null);c(this,"activeIssueId",null);c(this,"ignoredIssueIds",new Set);c(this,"currentResult",null);c(this,"currentAdapter",null);c(this,"redrawTimer",null);c(this,"hideTimer",null);c(this,"undoStack",[]);c(this,"fadeGeneration",0);this.injectStyles(),this.createSentinel(),this.createTooltip(),this.createLoader(),this.attachGlobalListeners(),this.attachUndoHandler()}render(t,e){this.currentResult=t,this.currentAdapter=e,h.info(`Rendering ${t.issues.length} issues`,"overlay-renderer"),this.fadeOutAndRedraw(e),this.broadcastIssueCounts(t)}setAnalysisPending(t){t?this.underlines.forEach(e=>e.elements.forEach(n=>n.classList.add("pc-pending"))):this.underlines.forEach(e=>e.elements.forEach(n=>n.classList.remove("pc-pending")))}clear(){this.removeAllUnderlines(),this.hideTooltip(),this.currentResult=null}setLoading(t){this.loader&&(t?this.loader.classList.add("pc-loading"):this.loader.classList.remove("pc-loading"))}createSentinel(){if(document.getElementById("promptcoach-overlay"))return;const t=document.createElement("div");t.id="promptcoach-overlay",t.style.cssText="position:fixed;top:0;left:0;width:0;height:0;pointer-events:none;z-index:-1",document.body.appendChild(t)}injectStyles(){if(document.getElementById("pc-styles"))return;const t=document.createElement("style");t.id="pc-styles",t.textContent=It,document.head.appendChild(t)}deduplicateIssues(t){const e={red:0,yellow:1,blue:2},n=[...t].sort((i,o)=>(e[i.severity]??1)-(e[o.severity]??1)),r=[];for(const i of n)r.some(a=>(e[a.severity]??1)<=(e[i.severity]??1)&&a.span.start<=i.span.start&&a.span.end>=i.span.end)?h.debug(`Dropping nested issue ${i.id} (${i.severity} inside a higher-severity span)`,"dedup"):r.push(i);return r}fadeOutAndRedraw(t){const e=++this.fadeGeneration;if(this.underlines.length===0){this.drawUnderlines(t);return}this.underlines.forEach(n=>n.elements.forEach(r=>{r.style.transition="opacity 0.12s",r.style.opacity="0"})),setTimeout(()=>{e===this.fadeGeneration&&this.drawUnderlines(t)},130)}drawUnderlines(t){var i;if(this.removeAllUnderlines(),!this.currentResult)return;const e=t.getOffsetMap();if(!e.length){h.warn("Empty offset map — cannot draw underlines","overlay-renderer");return}const n=((i=e[e.length-1])==null?void 0:i.nodeEnd)??0,r=this.deduplicateIssues(this.currentResult.issues.filter(o=>!this.ignoredIssueIds.has(o.id)));for(const o of r)try{const a=o.span.end-o.span.start,l=E.APPEND_CATEGORIES.has(o.category),d=n>0&&a>n*.55;if(l&&d){const u=this.renderAdditiveMarker(o,e);u&&this.underlines.push(u)}else{const u=this.drawIssueUnderline(o,e);u&&this.underlines.push(u)}}catch(a){h.error(`Failed to draw underline for issue ${o.id}`,"overlay-renderer",a instanceof Error?a:new Error(String(a)))}}drawIssueUnderline(t,e){const n=e.length>0?e[e.length-1].nodeEnd:0,r=Math.min(t.span.start,n),i=Math.min(t.span.end,n);if(r>=i)return h.warn(`Issue ${t.id} has zero-width span after clamping (${r}-${i}), skipping`,"overlay-renderer"),null;const o=this.buildRange(e,r,i);if(!o)return null;let a;try{a=Array.from(o.getClientRects())}catch{return null}if(!a.length)return null;const l=[],d=`pc-underline-${kt(t.severity)}`,u=[];for(const f of a){if(f.width<2||f.height<1)continue;const g=document.createElement("span");g.className=`pc-underline ${d}`,g.style.cssText=`
        left: ${f.left}px;
        top: ${f.top}px;
        width: ${f.width}px;
        height: ${f.height}px;
      `,g.dataset.issueId=t.id;const m=f;g.addEventListener("mouseenter",()=>{const p=g.getBoundingClientRect();this.showTooltip(t,p.width>0?p:m,g)}),g.addEventListener("mouseleave",p=>this.handleMouseLeave(p)),document.body.appendChild(g),l.push(g),u.push(f)}return l.length===0?null:{issue:t,elements:l,rects:u}}renderAdditiveMarker(t,e){if(!e.length)return null;const n=e[e.length-1],r=Math.max(0,n.nodeEnd-1),i=this.buildRange(e,r,n.nodeEnd);if(!i)return null;let o;try{o=Array.from(i.getClientRects())}catch{return null}if(!o.length)return null;const a=o[o.length-1],l=document.createElement("span");l.className="pc-additive-badge",l.dataset.issueId=t.id,l.textContent="+",l.title=t.explanation;const d=15;return l.style.cssText=`
      position: fixed;
      left: ${a.right+4}px;
      top: ${a.top+(a.height-d)/2}px;
      width: ${d}px;
      height: ${d}px;
      border-radius: 50%;
      background: rgba(96, 165, 250, 0.12);
      border: 1.5px solid rgba(96, 165, 250, 0.7);
      color: #60a5fa;
      font-size: 10px;
      font-weight: 700;
      font-family: system-ui, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 999998;
      pointer-events: all;
      user-select: none;
      transition: background 0.15s, transform 0.15s;
      line-height: 1;
    `,l.addEventListener("mouseenter",()=>{this.hideTimer&&(clearTimeout(this.hideTimer),this.hideTimer=null),l.style.background="rgba(96, 165, 250, 0.28)",l.style.transform="scale(1.15)";const u=l.getBoundingClientRect();this.showTooltip(t,u,l)}),l.addEventListener("mouseleave",u=>{l.style.background="rgba(96, 165, 250, 0.12)",l.style.transform="",this.handleMouseLeave(u)}),document.body.appendChild(l),{issue:t,elements:[l],rects:o}}buildRange(t,e,n){let r=null,i=0,o=null,a=0;for(const l of t)if(!r&&l.nodeEnd>e&&(r=l.node,i=Math.min(e-l.nodeStart,l.node.length)),!o&&l.nodeEnd>=n){o=l.node,a=Math.min(n-l.nodeStart,l.node.length);break}if(!r||!o)return null;try{const l=document.createRange();return l.setStart(r,i),l.setEnd(o,a),l}catch{return null}}createTooltip(){const t=document.createElement("div");t.id="pc-tooltip",t.setAttribute("role","tooltip"),t.addEventListener("mouseenter",()=>{this.hideTimer&&(clearTimeout(this.hideTimer),this.hideTimer=null),this.activeIssueId=t.dataset.issueId??null}),t.addEventListener("mouseleave",e=>{var r;const n=e.relatedTarget;(r=n==null?void 0:n.dataset)!=null&&r.issueId||this.scheduleHide()}),document.body.appendChild(t),this.tooltip=t}showTooltip(t,e,n){var g,m;if(!this.tooltip)return;this.hideTimer&&(clearTimeout(this.hideTimer),this.hideTimer=null),this.activeIssueId=t.id;const r=this.tooltip;r.dataset.issueId=t.id;const i=Ct(t.severity),o=Tt(t.severity),a=At(t.severity),d=(t.suggestions??[]).filter(p=>typeof p=="string"&&p.trim().length>0).slice(0,2).map((p,y)=>`
        <button class="pc-suggestion-btn" data-suggestion="${$(p)}" data-issue-id="${t.id}" data-suggestion-idx="${y}">
          ${$(p)}
        </button>
      `).join(""),f=E.APPEND_CATEGORIES.has(t.category)?"Add to prompt":"Replace with";try{r.innerHTML=`
        <div class="pc-tooltip-header">
          <span class="pc-severity-badge" style="background:${o};color:${i};">${a}</span>
          <button class="pc-close-btn" data-close="true" title="Dismiss">✕</button>
        </div>
        <div class="pc-tooltip-explanation">${$(t.explanation??t.category)}</div>
        ${d?`
          <div class="pc-suggestions-label">${f}</div>
          <div class="pc-suggestions">${d}</div>
        `:""}
        <div class="pc-tooltip-footer">
          <button class="pc-ignore-btn" data-ignore="${t.id}">Ignore</button>
        </div>
      `}catch(p){h.error("Tooltip HTML build failed","showTooltip",p instanceof Error?p:new Error(String(p)));return}r.querySelectorAll(".pc-suggestion-btn").forEach(p=>{p.addEventListener("click",y=>{const b=y.currentTarget,x=b.dataset.suggestion??"",T=b.dataset.issueId??"";b.disabled=!0,b.textContent="Applying…",this.applySuggestion(T,x)})}),(g=r.querySelector("[data-close]"))==null||g.addEventListener("click",()=>this.hideTooltip()),(m=r.querySelector("[data-ignore]"))==null||m.addEventListener("click",p=>{const y=p.currentTarget.dataset.ignore??"";this.ignoreIssue(y)}),this.positionTooltip(e),requestAnimationFrame(()=>{r.classList.add("pc-visible")})}positionTooltip(t){if(!this.tooltip)return;const e=this.tooltip,n=300,r=10,i=12;e.style.left="-9999px",e.style.top="-9999px",e.style.width=`${n}px`,e.style.removeProperty("opacity"),e.style.removeProperty("transform"),e.style.removeProperty("pointer-events");const o=e.offsetHeight||180,a=window.innerWidth,l=window.innerHeight;let d=t.top-o-r,u=t.left;d<i&&(d=t.bottom+r),u+n>a-i&&(u=a-n-i),u<i&&(u=i),d+o>l-i&&(d=Math.max(i,l-o-i)),e.style.left=`${u}px`,e.style.top=`${d}px`,e.style.width=`${n}px`}hideTooltip(){this.tooltip&&(this.tooltip.classList.remove("pc-visible"),this.activeIssueId=null)}scheduleHide(){this.hideTimer&&clearTimeout(this.hideTimer),this.hideTimer=setTimeout(()=>{this.hideTimer=null,this.hideTooltip()},220)}handleMouseLeave(t){var n,r;const e=t.relatedTarget;(n=e==null?void 0:e.closest)!=null&&n.call(e,"#pc-tooltip")||((r=e==null?void 0:e.dataset)==null?void 0:r.issueId)!==this.activeIssueId&&this.scheduleHide()}async applySuggestion(t,e){var r;const n=(r=this.currentResult)==null?void 0:r.issues.find(i=>i.id===t);if(!(!n||!this.currentAdapter))try{const i=this.currentAdapter.getText(),o=n.span.start,a=Math.min(n.span.end,i.length),l=a-o,d=i.length,u=E.APPEND_CATEGORIES.has(n.category),f=l>d*.55,g=u&&f;if(this.undoStack.push(i),this.undoStack.length>E.MAX_UNDO&&this.undoStack.shift(),g){let m=i.trimEnd();const p=/^[a-z]/.test(e.trim()),y=/[.!?]$/.test(m);let b;p?b=" ":y?b=`
`:b=". ";const x=m+b+e.trim();this.currentAdapter.setText(x),h.info(`Appended suggestion for issue ${t}: "${e}"`,"overlay-renderer")}else{let m=e;try{const Q=this.callRefine(i,o,a,e,n.category),J=new Promise(V=>setTimeout(()=>V(e),400));m=await Promise.race([Q,J])}catch{m=e}const y=i.slice(o,a).match(/([.!?])\s*$/),b=/[.!?]\s*$/.test(m);let x=m.trimEnd();y&&!b&&(x+=y[1]);const T=i[a];T&&T!==" "&&T!==`
`&&!x.endsWith(" ")&&!x.endsWith(`
`)&&(x+=" "),this.currentAdapter.replaceRange(o,a,x),h.info(`Replaced span [${o}-${a}] for issue ${t}: "${x}"`,"overlay-renderer")}chrome.runtime.sendMessage({type:"FEEDBACK",payload:{suggestionId:t,accepted:!0,category:n.category}}).catch(()=>{}),this.removeIssueUnderline(t),this.hideTooltip()}catch(i){h.error(`Failed to apply suggestion for issue ${t}`,"overlay-renderer",i instanceof Error?i:new Error(String(i)))}}async callRefine(t,e,n,r,i){var o;try{const a=await chrome.runtime.sendMessage({type:"REFINE_REQUEST",payload:{fullText:t,spanStart:e,spanEnd:n,suggestion:r,category:i}});if((a==null?void 0:a.type)==="REFINE_RESPONSE"&&((o=a.payload)!=null&&o.refinedSuggestion))return a.payload.refinedSuggestion}catch(a){h.debug(`Refine call failed, using original: ${a.message}`,"overlay-renderer")}return r}ignoreIssue(t){var n;this.ignoredIssueIds.add(t),this.removeIssueUnderline(t),this.hideTooltip();const e=(n=this.currentResult)==null?void 0:n.issues.find(r=>r.id===t);e&&chrome.runtime.sendMessage({type:"FEEDBACK",payload:{suggestionId:t,accepted:!1,category:e.category}})}removeIssueUnderline(t){const e=this.underlines.find(n=>n.issue.id===t);e&&(e.elements.forEach(n=>n.remove()),this.underlines=this.underlines.filter(n=>n.issue.id!==t))}removeAllUnderlines(){this.underlines.forEach(t=>t.elements.forEach(e=>e.remove())),this.underlines=[]}createLoader(){const t=document.createElement("div");t.id="pc-loader",t.innerHTML='<div class="pc-loader-dot"></div><span>Analyzing…</span>',document.body.appendChild(t),this.loader=t}attachGlobalListeners(){const t=()=>{this.redrawTimer&&clearTimeout(this.redrawTimer),this.redrawTimer=setTimeout(()=>{this.currentResult&&this.currentAdapter&&(this.fadeGeneration++,this.drawUnderlines(this.currentAdapter))},60)};window.addEventListener("scroll",t,{passive:!0}),window.addEventListener("resize",t,{passive:!0})}attachUndoHandler(){document.addEventListener("keydown",t=>{var o;if(!((t.ctrlKey||t.metaKey)&&t.key==="z"&&!t.shiftKey)||this.undoStack.length===0)return;const e=(o=this.currentAdapter)==null?void 0:o.getEditorElement();if(!e)return;const n=document.activeElement;if(!(n===e||e.contains(n)||(n==null?void 0:n.getAttribute("contenteditable"))==="true"))return;t.preventDefault(),t.stopPropagation();const i=this.undoStack.pop();this.currentAdapter.setText(i),this.removeAllUnderlines(),this.hideTooltip(),h.info(`Undo: restored ${i.length} chars (${this.undoStack.length} states left)`,"undo")},!0)}broadcastIssueCounts(t){const e={red:0,orange:0,blue:0};t.issues.forEach(n=>{n.severity==="red"?e.red++:n.severity==="yellow"?e.orange++:n.severity==="blue"&&e.blue++});try{window.postMessage({type:"PROMPTCOACH_ISSUES",...e},"*")}catch{}}};c(E,"MAX_UNDO",20),c(E,"APPEND_CATEGORIES",new Set(["missing_output_format","unspecified_audience","missing_constraints","missing_context","unclear_tone","poor_structure"]));let P=E;function $(s){return s==null?"":String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const q="pc-scan-btn",H="pc-scan-tip",z="pc-scan-css",Lt=30*60*1e3;class Ot{constructor(){c(this,"el",null);c(this,"tipEl",null);c(this,"state","stale");c(this,"lastUrl",location.href);c(this,"editorEl",null);c(this,"rafId",null);c(this,"urlTimer",null);c(this,"onScan",null)}mount(t,e){var n,r;this.onScan=t,this.editorEl=e,(n=document.getElementById(q))==null||n.remove(),(r=document.getElementById(H))==null||r.remove(),this.injectCSS(),this.el=this.buildButton(),this.tipEl=this.buildTooltip(),document.body.appendChild(this.tipEl),document.body.appendChild(this.el),this.updatePosition(),this.startPositionLoop(),this.refreshFromStorage(),this.urlTimer=setInterval(()=>{location.href!==this.lastUrl?(this.lastUrl=location.href,this.setState("stale")):this.refreshFromStorage()},2e3)}unmount(){var t,e;(t=this.el)==null||t.remove(),(e=this.tipEl)==null||e.remove(),this.el=this.tipEl=null,this.rafId!=null&&cancelAnimationFrame(this.rafId),this.urlTimer&&clearInterval(this.urlTimer)}setState(t){this.state=t,this.renderState()}startPositionLoop(){const t=()=>{this.updatePosition(),this.rafId=requestAnimationFrame(t)};this.rafId=requestAnimationFrame(t)}updatePosition(){const t=this.el;if(t){if(this.editorEl&&document.body.contains(this.editorEl)){const e=this.editorEl.getBoundingClientRect();if(e.width>0&&e.height>0){const n=Math.max(8,window.innerWidth-e.right+8),r=Math.max(8,window.innerHeight-e.bottom+8);t.style.right=`${n}px`,t.style.bottom=`${r}px`,t.style.top="",t.style.left="";return}}t.style.right="20px",t.style.bottom="100px",t.style.top="",t.style.left=""}}buildButton(){const t=document.createElement("button");return t.id=q,t.type="button",t.setAttribute("aria-label","PromptCoach — scan conversation context"),t.addEventListener("mouseenter",()=>this.showTip()),t.addEventListener("mouseleave",()=>this.hideTip()),t.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),this.handleClick()}),this.renderState(t),t}buildTooltip(){const t=document.createElement("div");return t.id=H,t}async handleClick(){var t;if(this.state!=="scanning"){this.setState("scanning");try{await((t=this.onScan)==null?void 0:t.call(this)),this.setState("fresh")}catch(e){console.warn("[PromptCoach] Scan failed:",e),this.setState("stale")}}}refreshFromStorage(){if(this.state==="scanning")return;const t=k();if(!t){this.setState("stale");return}const e=Date.now()-t.lastUpdatedAt>Lt,n=location.origin+"/"+location.pathname.split("/").slice(1,3).join("/"),r=!t.sourceUrl.split("?")[0].startsWith(n);this.setState(e||r?"stale":"fresh")}renderState(t=this.el){t&&(t.classList.remove("pc-stale","pc-scanning","pc-fresh"),t.classList.add(`pc-${this.state}`),this.state==="scanning"?t.innerHTML='<span class="pc-ring"></span>':this.state==="fresh"?t.innerHTML='<span class="pc-tick">✓</span>':t.innerHTML=`<svg width="13" height="13" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
        <circle cx="12" cy="12" r="9"/>
        <circle cx="12" cy="12" r="3"/>
        <path d="M12 3v2m0 14v2M3 12h2m14 0h2"/>
      </svg>`)}showTip(){if(!this.el||!this.tipEl)return;const t=this.el.getBoundingClientRect();this.tipEl.style.top=`${t.top+t.height/2-14}px`,this.tipEl.style.left=`${t.right+6}px`,this.tipEl.style.opacity="1",this.tipEl.textContent=this.state==="fresh"?"✓ Up to date — click to re-scan":this.state==="scanning"?"Scanning…":"Scan conversation for context"}hideTip(){this.tipEl&&(this.tipEl.style.opacity="0")}injectCSS(){if(document.getElementById(z))return;const t=document.createElement("style");t.id=z,t.textContent=`
      #pc-scan-btn {
        position: fixed;
        width: 30px; height: 30px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        padding: 0;
        outline: none;
        font-family: system-ui, sans-serif;
        transition: transform 0.18s cubic-bezier(.34,1.56,.64,1);
        box-shadow: 0 2px 8px rgba(0,0,0,0.25);
      }
      #pc-scan-btn:hover { transform: scale(1.2); }
      #pc-scan-btn:active { transform: scale(0.92); }

      #pc-scan-btn.pc-stale {
        background: linear-gradient(135deg,#f87171,#dc2626);
        animation: pc-pulse-r 2.5s ease-in-out infinite;
      }
      @keyframes pc-pulse-r {
        0%,100% { box-shadow: 0 0 0 0 rgba(220,38,38,.4); }
        50%      { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
      }
      #pc-scan-btn.pc-scanning {
        background: linear-gradient(135deg,#6366f1,#8b5cf6);
        animation: pc-pulse-p 1.2s ease-in-out infinite;
      }
      @keyframes pc-pulse-p {
        0%,100% { box-shadow: 0 0 0 0 rgba(99,102,241,.5); }
        50%      { box-shadow: 0 0 0 5px rgba(99,102,241,0); }
      }
      #pc-scan-btn.pc-fresh {
        background: linear-gradient(135deg,#4ade80,#16a34a);
        box-shadow: 0 2px 8px rgba(22,163,74,.3);
      }

      .pc-ring {
        display: block; width:14px; height:14px;
        border: 2px solid rgba(255,255,255,.3);
        border-top-color:#fff; border-radius:50%;
        animation: pc-spin .75s linear infinite;
      }
      @keyframes pc-spin { to { transform: rotate(360deg); } }

      .pc-tick {
        font-weight:700; font-size:14px;
        animation: pc-pop .35s cubic-bezier(.34,1.56,.64,1) forwards;
      }
      @keyframes pc-pop {
        0%   { transform:scale(0) rotate(-30deg); opacity:0 }
        70%  { transform:scale(1.3) rotate(6deg); opacity:1 }
        100% { transform:scale(1) rotate(0); opacity:1 }
      }

      #pc-scan-tip {
        position: fixed;
        font-size: 11.5px; line-height: 1.4;
        background: rgba(10,10,20,.93);
        backdrop-filter: blur(8px);
        color: rgba(255,255,255,.92);
        padding: 5px 10px; border-radius: 7px;
        white-space: nowrap; pointer-events: none;
        opacity: 0; transition: opacity .15s;
        z-index: 2147483647;
        box-shadow: 0 2px 12px rgba(0,0,0,.3);
        border: 1px solid rgba(255,255,255,.08);
        font-family: system-ui, sans-serif;
      }
    `,document.head.appendChild(t)}}function X(s=40){return(Rt()??$t()??Pt()??Mt()??_t()??Bt()??Ut()??[]).slice(-s)}function Rt(){const s=Array.from(document.querySelectorAll("[data-message-author-role]"));if(!s.length)return null;const t=s.filter(n=>{var r;return!((r=n.parentElement)!=null&&r.closest("[data-message-author-role]"))});if(!t.length)return null;const e=[];for(const n of t){const r=n.getAttribute("data-message-author-role")??"";let i;if(r==="human"||r==="user")i="user";else if(r==="assistant")i="assistant";else continue;const o=C(n);o&&e.push({role:i,content:o})}return e.length?e:null}function $t(){const s=Array.from(document.querySelectorAll('article[data-testid^="conversation-turn"]'));if(!s.length)return null;const t=[];for(const e of s){const n=e.querySelector("[data-message-author-role]"),r=(n==null?void 0:n.getAttribute("data-message-author-role"))??"",i=e.getAttribute("data-testid")??"";let o;if(r==="user"||i.includes("user"))o="user";else if(r==="assistant"||i.includes("assistant"))o="assistant";else continue;const a=C(e);a&&t.push({role:o,content:a})}return t.length?t:null}function Pt(){const s=Array.from(document.querySelectorAll("user-query")),t=Array.from(document.querySelectorAll("model-response"));if(!s.length&&!t.length)return null;const e=[...s,...t].sort((r,i)=>r.compareDocumentPosition(i)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1),n=[];for(const r of e){const i=r.tagName.toLowerCase()==="user-query",o=C(r);o&&n.push({role:i?"user":"assistant",content:o})}return n.length?n:null}function Mt(){const s=location.hostname;if(!(s.includes("claude")||s.includes("anthropic")))return null;const e=Nt();if(!e)return null;const n=Array.from(e.querySelectorAll(":scope > div, :scope > article, :scope > section")).filter(r=>{const i=(r.textContent??"").trim(),o=r.getBoundingClientRect();return i.length>20&&(o.height>0||r.offsetHeight>0)});if(n.length<2){const r=Array.from(e.querySelectorAll(":scope > div > div")).filter(i=>(i.textContent??"").trim().length>20&&i.offsetHeight>0);return r.length>=2?G(r):null}return G(n)}function G(s){const t=[];for(let e=0;e<s.length;e++){const n=s[e],r=C(n);if(!r)continue;const i=n.querySelector("pre, code")!==null,o=n.querySelector("ol, ul")!==null,a=r.length>250,l=i||o||a,d=e%2===0?"user":"assistant";let u;l&&d==="assistant"?u="assistant":!l&&d==="user"?u="user":u=d,t.push({role:u,content:r})}return t.length>=2?t:null}function Nt(){const s=Array.from(document.querySelectorAll("div, main, section")).filter(t=>{var i;const e=getComputedStyle(t),n=t.getBoundingClientRect(),r=e.overflowY;return(r==="auto"||r==="scroll")&&n.height>300&&n.width>300&&(((i=t.textContent)==null?void 0:i.length)??0)>500});return s.length?s.reduce((t,e)=>{var n,r;return(((n=e.textContent)==null?void 0:n.length)??0)>(((r=t.textContent)==null?void 0:r.length)??0)?e:t}):null}function _t(){const s=['[data-testid="human-turn"]','[data-testid="human-turn-content"]','[data-testid*="human"]'].join(","),t=['[data-testid="ai-turn"]','[data-testid="ai-turn-content"]','[data-testid*="assistant"]'].join(","),e=Array.from(document.querySelectorAll(s)),n=Array.from(document.querySelectorAll(t));return!e.length&&!n.length?null:Y(e,n)}function Bt(){const s=[".human-turn",'[class*="HumanTurn"]','[class*="human_turn"]','[class*="UserMessage"]','[class*="user-message"]'].join(","),t=[".claude-message",'[class*="AssistantTurn"]','[class*="AIMessage"]','[class*="ai-message"]','[class*="BotMessage"]'].join(","),e=Array.from(document.querySelectorAll(s)),n=Array.from(document.querySelectorAll(t));return!e.length&&!n.length?null:Y(e,n)}function Ut(){const s=document.querySelector("main")||document.querySelector('[role="main"]')||document.querySelector('[class*="conversation"]')||document.querySelector('[class*="chat-content"]')||document.querySelector('[class*="thread"]');if(!s)return null;const t=Array.from(s.querySelectorAll(":scope > div")).filter(n=>(n.textContent??"").trim().length>30&&n.getBoundingClientRect().height>0);if(t.length<2)return null;const e=[];return t.forEach((n,r)=>{const i=C(n);i&&e.push({role:r%2===0?"user":"assistant",content:i})}),e.length?e:null}function Y(s,t){const e=[...s.map(r=>({el:r,role:"user"})),...t.map(r=>({el:r,role:"assistant"}))].sort((r,i)=>r.el.compareDocumentPosition(i.el)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1),n=[];for(const{el:r,role:i}of e){const o=C(r);o&&n.push({role:i,content:o})}return n.length?n:null}function C(s){const t=s.querySelectorAll("p, li, pre, h1, h2, h3, h4");return t.length?Array.from(t).map(e=>{var n;return((n=e.textContent)==null?void 0:n.trim())??""}).filter(Boolean).join(" ").slice(0,500):(s.textContent??"").trim().slice(0,500)}it();let I=!1,v=null;chrome.runtime.onMessage.addListener((s,t,e)=>{var n,r;switch(s.type){case"READ_CONVERSATION_HISTORY":{const i=((n=s.payload)==null?void 0:n.maxMessages)??20,o=X(i);return e({payload:{messages:o}}),!1}case"STORE_SESSION_CONTEXT":{const{summary:i,messageCount:o}=s.payload??{};return i&&W(i,o??0),e({payload:{ok:!0}}),!1}case"GET_SESSION_CONTEXT":return e({payload:k()}),!1;case"CLEAR_SESSION_CONTEXT":return lt(),v&&v.setState("stale"),e({payload:null}),!1;case"SET_SCAN_BTN_STATE":return v&&((r=s.payload)!=null&&r.state)&&v.setState(s.payload.state),!1;default:return!1}});async function F(){var e,n;const s=X(20);if(!s.length)throw new Error("No conversation messages found on this page. Start a chat first, then scan.");const t=await chrome.runtime.sendMessage({type:"SCAN_CONTEXT_REQUEST",payload:{messages:s,sourceUrl:location.href}});if(!((e=t==null?void 0:t.payload)!=null&&e.summary))throw new Error(((n=t==null?void 0:t.payload)==null?void 0:n.error)??"Summarization failed");W(t.payload.summary,t.payload.messageCount??s.length),h.info(`Context scanned: ${s.length} messages → ${t.payload.summary.length} chars`,"scan")}function Dt(s){s.onSubmit(async t=>{var n;const e=k();if(e)try{const r=await chrome.runtime.sendMessage({type:"TRACK_PROMPT_REQUEST",payload:{prompt:t,sessionId:at(),currentSummary:e.summary,promptCount:e.promptCount}});(n=r==null?void 0:r.payload)!=null&&n.summary&&(ct(r.payload.summary,r.payload.promptCount),h.debug(`Context updated: count=${r.payload.promptCount}`,"submit-hook"))}catch(r){h.debug(`Submit tracking silently failed: ${r.message}`,"submit-hook")}})}function K(){if(I)return;const s=St();if(!s){h.warn("No adapter detected for this page","boot");return}const t=new P;ht(s,t),Dt(s),v=new Ot;function e(){const i=s.getEditorElement();v.mount(F,i)}e();let n=0;const r=setInterval(()=>{const i=s.getEditorElement();(i||++n>=10)&&(clearInterval(r),i&&(v.unmount(),v.mount(F,i)))},500);I=!0,h.info(`Booted with adapter: ${s.name}`,"boot")}K();if(!I){const s=new MutationObserver(()=>{K(),I&&s.disconnect()});s.observe(document.body,{childList:!0,subtree:!0})}
})()
