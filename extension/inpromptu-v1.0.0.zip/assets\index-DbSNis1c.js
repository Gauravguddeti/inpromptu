const e={analysisEnabled:!0,memoryEnabled:!0,modelSpeed:"quality",privacyMode:!1,activeProjectId:null};export{e as D};
